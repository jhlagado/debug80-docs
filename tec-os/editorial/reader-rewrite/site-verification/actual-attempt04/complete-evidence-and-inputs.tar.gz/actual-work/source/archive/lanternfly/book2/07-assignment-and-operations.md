---
layout: default
title: "Assignment and Standard Operations"
parent: "Lanternfly Book 2 — Language Reference"
nav_order: 7
---

# Assignment and Standard Operations

Lanternfly uses `=` for both assignment and equality, following their familiar
BASIC roles. Assignment is a statement; equality is an expression operator.
The surrounding grammar makes the meaning unambiguous.

## Assignment

```lanternfly
playerScore = playerScore + 10
player.position.x = nextX
```

Because assignment is not an expression, it cannot be chained or nested
inside a larger calculation. Compound forms such as `+=` are also absent.

The parser selects assignment when a statement begins with a writable storage
path followed by `=`. Elsewhere, `=` means equality:

```lanternfly
if playerScore = highScore then
    showHighScore()
end
```

## Destination conversion

An exact literal adopts the scalar destination type when it fits.

Integer assignment uses the same bit conversion as an explicit integer
conversion:

- value-preserving widening is silent;
- narrowing or changing signedness warns with `W-CONVERT-001` by default;
- a project may promote that warning to an error.

Assignment to an enum or subrange performs the checked ordinal conversion. A
known value outside the destination domain is a compile error; a dynamic
failure causes `F-RANGE` before the destination changes.

The same destination rules apply to initializers, scalar arguments, returned
values, `fill` values and counted-loop starts.

## Round-trip arithmetic exemption

An arithmetic update can store its result back into its original integer type
without `W-CONVERT-001` when:

- the destination has type `T`;
- every typed value leaf also has type `T`;
- every exact leaf resolves as `T`;
- the expression contains only parentheses and integer operators.

```lanternfly
lives = lives - 1
position = position + velocity
bytes[index] = bytes[index] + 1
```

Wider intermediate types from the operator table remain part of the exempt
round trip. Index expressions and record-selection prefixes locate the loaded
value and do not count as arithmetic value leaves.

An explicit conversion to another type or a standard operation such as `abs`
ends the exemption.

## Equality and ordering

| Operator | Meaning               |
| -------- | --------------------- |
| `=`      | equal                 |
| `<>`     | not equal             |
| `<`      | less than             |
| `<=`     | less than or equal    |
| `>`      | greater than          |
| `>=`     | greater than or equal |

Comparison chaining is invalid. Integer comparisons use the compatibility
rules from [Chapter 4](04-integer-expressions.md#compatible-operand-types).
Subranges compare through their base ordinal family. Enum comparisons require
the same nominal enum and follow declaration order. Booleans support `=` and
`<>`. Opaque addresses support `=` and `<>` when their classes match. Strings
support all six operators and compare their current content, even when their
capacities differ.

Record and array equality is deferred. Programs compare their selected fields
or elements explicitly.

## Standard value operations

The standard value operations are part of the language kernel and require no
import.

### `abs`

`abs(value)` accepts an integer. An unsigned operand is unchanged. A signed
operand produces the unsigned type of the same width:

```lanternfly
var magnitude as u16 = abs(i16(-32768))
```

### `sqrt`

`sqrt(value)` returns the floor of a non-negative square root in the unsigned
type of the operand's width. A negative constant is a compile error; a
negative runtime operand causes `F-NEGATIVE-SQRT`.

### `length`

`length(text)` accepts `string[N]` or a string literal and returns its payload
byte count as `u16`. It reads a string's stored header without scanning the
payload. Literal calls fold at compile time.

## Layout queries

Layout queries are compile-time operations. Most produce exact, untyped
integers; `lower` and `upper` preserve a nominal ordinal domain when one
defines the selected dimension:

```lanternfly
const actorBytes as u16 = size(type Actor)
const tableBytes as u16 = size(actors)
const actorCount as u8 = count(actors)
const rowCount as u8 = count(board, 0)
const firstRow as u8 = lower(board, 0)
const lastRow as u8 = upper(board, 0)
const xOffset as u8 = offset(Actor.position.x)
```

`size(type Type)` returns a type's byte size. `size(path)` returns the size of
a statically typed path.

`count(type ArrayType)` and `count(path)` return array extents. A
multidimensional array requires a zero-based dimension argument.

`lower` and `upper` return the first and last valid ordinal for an array
dimension. They preserve an enum or subrange result type and otherwise return
an exact integer.

`offset(Record.fieldPath)` returns a field path's byte offset from the
beginning of its record type. Intermediate fields must be by-value records.

A layout-query path is unevaluated. It may use fields and constant indices,
but cannot call routines or evaluate dynamic indices. The compiler validates
constant indices without reading storage or running a bounds check.

## Aggregate and string operations

`clear`, `fill` and `append` have the internal result type `unit` and are valid
only as complete statements:

```lanternfly
clear(board)
fill(framebuffer, backgroundColour)
append(playerName, '!')
```

`clear(target)` writes the all-zero representation through a writable counted
string, record or fixed array. Every leaf must accept zero. A counted string
becomes empty.

`fill(target, value)` requires a writable fixed array with a scalar leaf type.
The value receives that type as its expected destination type and is evaluated
and converted once. Every element receives the converted value in row-major
order. A conversion produces at most one warning for the statement.

`append(destination, source)` requires a writable counted-string destination.
The source may be another string, a string literal or a nonzero `u8` byte. It
checks the final length and byte invariant before writing; failure causes
`F-RANGE` without changing the destination. Source and destination may overlap
because the operation has snapshot semantics.

All three operations evaluate the destination path once. `fill` and `append`
then evaluate their second argument once before storing. Their writes are
observable; volatile aggregates receive ordered scalar writes.

## Expression statements

Any expression may stand as a statement:

```lanternfly
updateClock()
distance(playerX, enemyX)
playerScore + 10
```

The statement discards its final value, but calls, volatile accesses, checks,
faults and short-circuit behaviour still occur. A pure expression statement
normally receives `W-EXPR-001`. A routine invocation is not warned merely
because its result is discarded.

## Evaluation order

Lanternfly fixes evaluation order across backends:

- statements execute in source order;
- invocation arguments evaluate left to right;
- unary operands evaluate before their operator;
- binary operands evaluate left to right, except for Boolean
  short-circuiting;
- path bases and indices evaluate left to right;
- assignment evaluates the destination path once, then the right-hand
  expression, then stores;
- array and record initializer elements evaluate in written order.

In this assignment, `nextIndex()` runs before `nextValue()`:

```lanternfly
actors[nextIndex()].x = nextValue()
```

A backend may reorder work only when no observable result, call, volatile
access, check or fault can distinguish the change.
