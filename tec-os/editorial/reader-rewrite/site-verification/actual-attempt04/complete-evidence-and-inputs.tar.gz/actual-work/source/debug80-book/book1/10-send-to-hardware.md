---
layout: default
title: "Sending to TEC-1G hardware"
parent: "Debug80 Book 1 — Getting started"
nav_order: 10
---

# Sending to TEC-1G hardware

Debug80 sends the active target's Intel HEX file to real hardware through CoolTerm. CoolTerm owns the serial port. Debug80 controls CoolTerm through its localhost Remote Control Socket.

## CoolTerm installation

CoolTerm is available from:

<https://freeware.the-meiers.org>

On macOS, the first launch may require approval in **System Settings > Privacy & Security**. You can also right-click CoolTerm in Finder, choose **Open** and confirm the launch.

![Emulator serial path versus CoolTerm hardware path](../../assets/images/debug80-book/book1/emulator-vs-coolterm-serial.svg)

## The Remote Control Socket

Under CoolTerm's **Preferences > Scripting**, **Remote Control Socket**
must be enabled on port `51413`.

The local IP shown in CoolTerm is informational.

## Serial port configuration

CoolTerm's **Connection > Options** selects the serial port for the USB
adapter, whose name depends on the adapter and operating system. This
workflow requires line settings of `4800 8 N 2`.

## Building and sending

With the correct project and target selected, **Build** creates the
required `.hex` file. This stage uses **Build** because only the
artifact is required.

The **Test CoolTerm** action checks CoolTerm's remote control socket before a
transfer. The ping is the whole action: it runs on an unbuilt project and
leaves the serial port closed, so a failure points at CoolTerm's socket alone.
On success Debug80 reports:

```text
Debug80: Connected to CoolTerm remote socket.
```

The TEC-1G must be in MON-3 Intel HEX Load mode before transmission.

**Send to TEC-1G** in the Project section starts the transmission.

The button's label follows the platform, so a TEC-1 project reads **Send to TEC-1** and anything else reads **Send to Board**. It is enabled once a target is selected and a HEX file exists; the panel's hardware status line displays any missing requirement:

```text
Ready to send main.hex via CoolTerm.
```

Confirmation comes from the board itself: MON-3 reports the load result on the TEC-1G seven-segment display, `PASS` for an accepted load and `ERROR` for a checksum or write verification failure.

If your target has no `outputDir`, the send path looks for the HEX beside `debug80.json` rather than in `build/`. Scaffolded projects always set `outputDir`, so this fallback applies only to hand-edited configurations.

The serial startup message `TEC-1G Connected` belongs to MON-3 startup, not to the transfer.

## Transfer failures

The observed failure identifies which part of the path to inspect:

- For a Debug80 connection failure, the relevant checks are that CoolTerm is open and the Remote Control Socket is enabled on port `51413`.
- A request for a HEX file means the active target needs to be built.
- `ERROR` on the TEC-1G calls for confirming that the board is in Intel HEX Load mode before another transfer.
- Missed characters can be addressed by adding transmit delay in CoolTerm.
