---
title: "Preface"
parent: "Delete the Implementation"
nav_order: 1
---

# Preface

Code generators now write code faster than anyone can read it. A programmer
who uses one has a choice to make about every routine it writes. One choice
is to read the code and take responsibility for it line by line. The other
is to trust it and hope. Neither scales, since reading every line gives up
most of the speed and trusting it gives up any claim to know what the
program does.

This book is about a third choice. I write down what a routine must do,
precisely enough that a machine can check it. A generator writes candidates
from that description alone. Deterministic tools judge each candidate
against it. A candidate replaces the existing code only when it passes every
check and the decision is recorded. The method calls that replacement a
landing. The description and the evidence are the parts I keep, and the code
itself becomes replaceable.

I call the method Origo, and I have applied it to four projects so far, each
of which I call a study:

- the first study rewrote the toolchain of a language for CP/M
- the second built assembly tools on top of the third study's operating system
- the third improved TEC-OS, an operating system held in ROM on the TEC-1G, a Z80 single-board computer
- the fourth is this book, written as a study

The studies use small machines on purpose. The routines measured so far run
from nine bytes to over 800. Each one's time can be counted exactly in
T-states, the clock cycles of the Z80. An emulator runs the whole system's
tests at every landing. Every claim can be checked against a figure, so the
method's mistakes show up as quickly as its successes.

## Readers

I wrote it for a working programmer who wants evidence about code
generators, as a user of them or someone weighing them up. You need to read
code comfortably, but no knowledge of the Z80 is assumed. The examples are
in Z80 assembly, and each one is explained as it appears. Some arithmetic on
cycle counts and byte counts runs through the book, and none of it goes
beyond a percentage.

## Results, good and bad

The method made a claim it could fail, and in places it did. The first study
regenerated small routines at high rates and large ones at none until their
interfaces were written down. Its largest gains came from structural changes
that were modelled first and then built through contracts. Its local
regeneration, routine by routine, gave smaller ones.

A study's work is divided into stages. Each is one planned piece of work
with its own record. The second study ran its first three stages without
generation (P2: T0 to T2). In the next it generated six candidates in a
round, one pass of generation and judgement (P2: T3). The round was meant to
keep each generator's first attempt as a control, to measure what the rest
of the round adds. Those first files were not archived, so the control is
lost (P2: T3). After the candidates were scored again, I decided that three
of them land (P2: the fix round).

A review written after the third study's warm-boot stage lists the places
where the method was not followed well (P3: the method review). I include
all of it, because a method that reports only its successes gives you no
reason to believe them.

## Two examples

The first is a round of regeneration on the first study's floating-point
routines. A generator writes each candidate from a bundle of the routine's
contract and some of its tests, with none of its code. Most of the round's
candidates passed every check, and the ones that landed made the routines
smaller. FMUL is the routine that multiplies two floating-point numbers. Its
worst case became about five times faster (P1: CDR-3). Chapter 2 opens with
FMUL's contract, and Part II follows the round from its bundles to its
landings.

The second is a stage from the third study. When a program ends, TEC-OS
returns to its command prompt through a warm boot. A warm boot took
3,866,040 T-states, almost a second at the board's 4 MHz clock (P3: KB-6).
The board's serial port carries the serial console, used from a terminal at
the other end. The figures here are all with that console. In that stage the
time was measured first. A design was then modelled on the host, the
computer the emulator and tools run on, before any Z80 was written.

A clean warm boot is one where nothing has changed a disk's directory or its
record of used blocks since that directory was last read. As built, a clean
warm boot took 81,040 T-states and read no disk block (P3: KD-72). `SAVE` is
the command that writes memory to a disk file. A warm boot after it read one
block and took 327,424 T-states (P3: KD-72).

The method's protocol is its written order of work. It now sets out a stage
track for work built once, nine steps that end in a review of the result
(MD-8). The method gives each study a backlog, a list of the problems it has
measured. The track's first step starts from a backlog item with a measured
cost or a request of mine. Among the nine are a written plan called a brief,
its review, a model and one build. The warm-boot stage ran before the track
was written and departed from it in four places, which chapter 7 sets out.

Part I covers the proposition, contracts and the checks that judge them.
Part II describes the loop of generation and judgement. Part III shows the
same checks governing work that is built once. Part IV describes a
specification language for contracts, part measured and part research. Part
V covers how a study is run: its records, its boundaries and its protocol.
Part VI reports what each of the first three studies found.

## Citations

Every figure in the book comes from the records, a study's or the method's
own. A study's records are cited with its number. In (P1: CDR-3), for
example, the record is the first study's first measured round of
regeneration. The method's own records are cited by their identifiers alone,
as (M1) for a rule or (MD-2) for a decision. The records are kept in the
Origo repository. Each stage of this book's study checks the chapters
against one named commit of it and records that commit. Where the book and
the records differ, the records are right.
