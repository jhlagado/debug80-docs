---
layout: default
title: "Appendix 1 — Directive Reference"
parent: "Appendices"
grand_parent: "AZM Books"
nav_order: 1
---

# Appendix 1 — Directive Reference

The table lists AZM directives and declaration keywords. Dotted directives use canonical lowercase forms and are case-sensitive. See Chapter 7 for the alias layer that normalises legacy undotted forms.

| Directive | Syntax | What it does | Ch. |
|-----------|--------|--------------|-----|
| `.org` | `.org expr` | Sets the assembly address counter to `expr`; assembly-time only | 3 |
| `.equ` | `NAME .equ expr` | Binds `NAME` to the constant value of `expr`; assembly-time only | 3 |
| `.if` | `.if expr` | Assembles the following branch when `expr` is non-zero | 3 |
| `.else` | `.else` | Selects the alternate branch of a conditional block | 3 |
| `.endif` | `.endif` | Closes a conditional block | 3 |
| `.db` | `.db expr[,expr…]` | Emits one or more 8-bit values; accepts string literals | 4 |
| `.dw` | `.dw expr[,expr…]` | Emits one or more 16-bit little-endian values | 4 |
| `.ds` | `.ds count[,fill]` | Reserves `count` bytes; optional `fill` byte; accepts type expressions | 4, 5 |
| `.include` | `.include "path"` | Inserts the named source file at this point | 7 |
| `.import` | `.import "path"` | Loads a source unit and exposes declarations marked with `@` | 7 |
| `.routine` | `.routine [noreturn] [in ...] [out ...] [maybe-out ...] [clobbers ...] [preserves ...]` | Starts a routine and declares its register contract | 6 |
| `.contracts` | `.contracts strict|audit|off` | Sets register-contract policy for the containing source file | 6 |
| `.rcignore` | `.rcignore finding "reason"` | Suppresses one local finding with required reason text | 6 |
| `.expectout` | `.expectout carriers` | Marks outputs intentionally consumed from the next emitted instruction in the same file | 6 |
| `.align` | `.align n` | Advances the address to the next multiple of `n`, inserting zero bytes | 3 |
| `.cstr` | `.cstr "text"` | Emits string bytes followed by a `$00` terminator (C-style) | 4 |
| `.pstr` | `.pstr "text"` | Emits a length byte followed by string bytes (Pascal-style) | 4 |
| `.istr` | `.istr "text"` | Emits string bytes with bit 7 set on the final byte | 4 |
| `.binfrom` | `.binfrom addr` | Marks the start address of the flat binary output range | 3 |
| `.binto` | `.binto addr` | Marks the end address of the flat binary output range | 3 |
| `.end` | `.end` | Marks the end of source; AZM stops assembling at this point | — |
| `.type` | `Name .type` … `.endtype` | Opens a record layout declaration block | 5 |
| `.endtype` | `.endtype` | Closes a `.type` block | 5 |
| `.union` | `Name .union` … `.endunion` | Opens a union layout declaration block | 5 |
| `.endunion` | `.endunion` | Closes a `.union` block | 5 |
| `.field` | `name .field TypeExpr` | Declares a field of any type inside a `.type` or `.union` block | 5 |
| `.byte` | `name .byte` | Declares a one-byte scalar field inside a `.type` or `.union` block | 5 |
| `.word` | `name .word` | Declares a two-byte scalar field inside a `.type` or `.union` block | 5 |
| `.addr` | `name .addr` | Declares a two-byte address field inside a `.type` or `.union` block | 5 |
| `.typealias` | `Name .typealias TypeExpr` | Transparent assembler-time alias for a layout type expression | 5 |
| `.enum` | `Name .enum Member[,…]` | Declares a group of integer constants with qualified names (`Name.Member`) | 3 |
| `op` / `end` | `op name(params)` … `end` | Declares an inline instruction-expansion op | 7 |

## Directive aliases

Project-specific forms such as `DEFB`, `DEFW` and `RMB` require a project alias file loaded with `--aliases`. See Chapter 7.

Built-in aliases (normalized before parsing):

| Alias | Canonical |
|-------|-----------|
| `ORG` | `.org` |
| `EQU` | `.equ` |
| `DB` | `.db` |
| `DW` | `.dw` |
| `DS` | `.ds` |
| `INCLUDE` | `.include` |
| `END` | `.end` |
| `ALIGN` | `.align` |
| `CSTR` | `.cstr` |
| `PSTR` | `.pstr` |
| `ISTR` | `.istr` |
| `BINFROM` | `.binfrom` |
| `BINTO` | `.binto` |

---

## Register contract carrier notation

Carriers in a `.routine` directive are comma-separated register names, flag names or register pair names. Register pairs expand to their constituent 8-bit registers during analysis:

| Pair notation | Expands to |
|--------------|------------|
| `BC` | `B,C` |
| `DE` | `D,E` |
| `HL` | `H,L` |
| `IX` | `IXH,IXL` |
| `IY` | `IYH,IYL` |
| `SP` | `SPH,SPL` |
| `AF` | `A,carry,zero,sign,parity,halfCarry` |
| `F` | `carry,zero,sign,parity,halfCarry` |

Individual flag names are `carry`, `zero`, `sign`, `parity` and `halfCarry`. `C` names register C. Chapter 6 describes the complete contract format.

![The pair and flag-set spellings against the carriers the analyzer tracks](../../assets/images/azm-book/book1/carrier-expansion.svg)
