---
layout: default
title: "Building with Subroutines"
parent: "Lanternfly Book 1 — Programming Fundamentals"
nav_order: 10
---

# Building with Subroutines

The routines in earlier chapters mostly read module variables. A reusable
routine receives the values that vary from one call to another:

```lanternfly
var total as i16 = 0

sub addToTotal(amount as i16)
    total = total + amount
end

sub main()
    addToTotal(10)
    addToTotal(25)
end
```

Each call supplies a fresh value for `amount`. The routine defines the update
once, and each call site supplies its own quantity.

## Parameters and arguments

Every user routine begins with `sub`. Parameters use the same
`name as Type` form as other declarations:

```lanternfly
sub addToTotal(amount as i16)
    total = total + amount
end
```

At the call site, an argument supplies the parameter value:

```lanternfly
addToTotal(nextAmount)
```

Scalar parameters pass by value. Changing `amount` inside the routine would
change its private parameter value, not `nextAmount` in the caller.

Arguments are evaluated from left to right before the routine begins. This
order matters when argument expressions call routines or perform other visible
work.

## Returning a result

A trailing result type turns a call into an expression:

```lanternfly
sub atMost(input as i16, maximum as i16) as i16
    if input > maximum then
        return maximum
    end

    return input
end
```

We can place the returned `i16` wherever an `i16` expression belongs:

```lanternfly
total = atMost(total + nextAmount, 1000)
```

Every reachable path in a result-bearing routine must return a compatible
scalar value. Strings, records and arrays
remain in caller-owned storage and are reached through aggregate
parameters and aliases.

A result-bearing call may stand alone when its side effects matter and its
result may be discarded. A result-free routine cannot appear where an
expression value is required.

## Scalar locals

Locals hold working values that belong to one invocation:

```lanternfly
sub absoluteDifference(left as u8, right as u8) as u16
    var difference as i16 = left - right

    return abs(difference)
end
```

Local declarations appear before executable statements. An initializer may
use parameters, module declarations and earlier locals. Code outside the
routine cannot name `difference`.

An owned scalar local with no initializer starts with zero bits. A string,
record or array is aggregate storage, so a routine reaches one through a
parameter, or through the alias form of Chapter 11, rather
than owning a local copy.

Overlapping invocations receive independent scalar parameters and
locals, wherever the compiler keeps them.

## Aggregate parameters

An array, record or string parameter aliases the caller's existing storage:

```lanternfly
sub clearBlock(block as u8[8])
    var index as i16

    for index = 0 until count(block)
        block[index] = 0
    end
end
```

The call supplies a compatible storage path:

```lanternfly
clearBlock(workspace)
```

Writing `block[index]` changes `workspace[index]`. The aggregate is not copied
into local stack storage.

An aggregate parameter states its exact shape. A string parameter names
its exact capacity, because the alias must match the caller's layout byte
for byte: `line as string[40]` accepts a `string[40]` and nothing else.

That is the ordinary rule for every routine we can write. The compiler-defined
services introduced in chapters 12 and 13 contain three narrow exceptions:
`writeText`, `readLine` and `readArgument` accept string storage of any
capacity. Routines shared between modules also state where the aggregate
lives, and Chapter 16 introduces that spelling with the interfaces that need
it.

## Early return

A result-free routine can leave early with bare `return`:

```lanternfly
sub normaliseReading(reading as Reading)
    if reading.quality = qualityInvalid then
        return
    end

    reading.value = atMost(reading.value, maximumReading)
end
```

The invalid case ends the call before the update. Handling it first keeps the
main work at the routine's outer indentation. Reaching the closing `end` also
returns from a result-free routine.

`return` leaves the subroutine. `exit` leaves the innermost loop, so the two
words describe different control boundaries.

## Calling order and recursion

Chapter 1's declaration order governs calls too. A routine body may call
imported routines, routines declared earlier in the module, and itself —
the routine's own name becomes visible at its header, so a direct
self-call is legal source. A call to a routine that has not yet appeared
is a declaration-before-use error.

What remains is the advanced case of declaration order. Two routines
that call each other cannot both come first under that rule;
`forward sub` resolves the order: it states a routine's complete header
ahead of its body, and from that line the routine can be called like any
other:

```lanternfly
forward sub updateEnemies()

sub updatePlayer()
    if playerCollides() then
        updateEnemies()
    end
end

sub updateEnemies()
    if enemyCollides() then
        updatePlayer()
    end
end
```

The rule is strict. The completing `sub` must appear later in the same
module and repeat the forward header exactly, and a forward declaration
still uncompleted when the module ends is a compile error. A forward
declaration changes declaration order only: it adds no runtime work, and
the call behaves like any other call.

Whether recursion is actually available — a self-call or a mutual cycle —
depends on the selected target. The reason is storage: every active
invocation needs an independent parameter-and-local frame, so a
recursion-capable profile defines frame layout and stack bounds, while a
profile based on fixed scratch storage rejects every source call-graph
cycle. The language reference states the complete frame and capability
rules.

## Complete program

The complete module contains value parameters, returned results, scalar
locals, an aggregate parameter and a forward-declared pair. Two calls to
`addToTotal` produce
35, and `atMost(total, 30)` then returns 30. `updatePlayer` and
`updateEnemies` may call each other because the forward declaration
supplies the missing signature; with both clash flags false, the pair
returns immediately. The mutual pair makes the module's call graph
cyclic, so this program requires a recursion-capable target profile.

<<< @/lanternfly-book/book1/code/10-routines.txt{lanternfly}


## Exercises

1. A routine assigns through a record parameter. Does the caller's
   record change, and why?

Answer: yes. An aggregate parameter aliases the caller's storage; it is
not a copy.

## Chapter summary

- Scalar parameters receive values from the caller, and arguments are
  evaluated from left to right.
- A trailing `as Type` declares a scalar result returned with `return`.
- Scalar locals hold private working values for one invocation.
- Record, array and string parameters alias caller-owned storage.
- A routine calls imported routines, earlier routines, itself or a
  forward-declared routine whose completing body comes later in the same
  module; recursion of any shape depends on whether the selected target
  profile can provide independent active frames.
