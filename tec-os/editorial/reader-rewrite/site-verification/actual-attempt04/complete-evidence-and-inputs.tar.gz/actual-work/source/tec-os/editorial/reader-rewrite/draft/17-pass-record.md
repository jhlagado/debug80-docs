# Chapter 17 pass record

## Contract and authority

The single job is to trace a card command and a CP/M record to its physical
block. The prerequisites are user volumes, records and the state/bank rules.
The outcome is an address whose container range, geometry, quarter-block and
write policy can each be explained. Only the two Chapter 17 draft paths are
owned by this change.

I read the complete original tec-os/17-sd-card-and-volumes.md, all 55 assigned
movement units, the closed replacement outline and its current KD243/KS48
amendment. The controlling original ranges below refer to frozen
10821b68f80c10d2037bbd1c5ab207877c897c68. The outline closed at0e4feea and was
recorded at3060e71. There are no separate fragment overrides for17.

Current mechanism authority is offered product
ea3ef3de9133931e925a0220d51c0e971c1fd8dd, inspected through Git objects.
This is a source-only account. The historical captures, recipes, SD block
measurements, SAVE count and TPA comparison retain78127ec. The diagnostics
678T full-poll figure also retains78127ec. No result is inferred for a later
font/default profile and no historical output has been repinned.

I applied the complete human-writing skill, its revision-playbook and
pattern-guide, the teaching standard and its reader/banned-pattern/review
references and the book style. The theme ladder is interface bytes, card
initialisation, block transfer, container validation, declared/physical bounds,
DPH/DPB, record mapping, write merge and service publication. Historical
failure examples stay next to their respective validation boundaries.

## Material accounting

Every assigned source unit has a disposition below. Technical paragraphs are
combined into new connected explanations. No technical unit or historical
example is deleted. Original roadmap wording is replaced by the record-size
problem. Headings and old navigation are replaced by final chapter structure.
The original checked/header comments become separate current-source and
historical-evidence metadata, not a header pin bump.

| Original unit | Disposition |
| --- | --- |
| `tec-os/17-sd-card-and-volumes.md:1-6` | Replace title/navigation or separate source and historical provenance in metadata. |
| `tec-os/17-sd-card-and-volumes.md:8-8` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:10-10` | Replace title/navigation or separate source and historical provenance in metadata. |
| `tec-os/17-sd-card-and-volumes.md:12-14` | Replace title/navigation or separate source and historical provenance in metadata. |
| `tec-os/17-sd-card-and-volumes.md:16-26` | Replace roadmap with record-size problem, eight disk entries and bounded address/cache relationship. |
| `tec-os/17-sd-card-and-volumes.md:28-28` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:30-36` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:38-43` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:45-50` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:52-53` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:55-75` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:77-87` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:89-99` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:101-109` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:111-116` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:118-123` | Bytes on the card interface, Initialisation and block addresses, Reading and writing a block. Retain pins, counts, errors, timings and bank/stack conditions with corrected scopes. |
| `tec-os/17-sd-card-and-volumes.md:125-125` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:127-136` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:138-147` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:149-154` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:156-167` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:169-179` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:181-185` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:187-200` | Container blocks and validation, Declared length and physical capacity. Retain fields, ordered checks, sums, descriptor rules and exact address bounds. Add the closed zero-extra-block exception. |
| `tec-os/17-sd-card-and-volumes.md:202-206` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:208-208` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:209-217` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:219-223` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:225-225` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:226-231` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:233-236` | Declared length and physical capacity. Retain fixture preparation, both complete captures/recipes and conditional error/retry explanation. |
| `tec-os/17-sd-card-and-volumes.md:238-238` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:240-252` | Drive entries and disk parameters. Retain DRVTAB/DRVIDX and all DPH/geometry facts, vector and warm-state relationships. |
| `tec-os/17-sd-card-and-volumes.md:254-257` | Drive entries and disk parameters. Retain DRVTAB/DRVIDX and all DPH/geometry facts, vector and warm-state relationships. |
| `tec-os/17-sd-card-and-volumes.md:259-266` | Drive entries and disk parameters. Retain DRVTAB/DRVIDX and all DPH/geometry facts, vector and warm-state relationships. |
| `tec-os/17-sd-card-and-volumes.md:268-276` | Drive entries and disk parameters. Retain DRVTAB/DRVIDX and all DPH/geometry facts, vector and warm-state relationships. |
| `tec-os/17-sd-card-and-volumes.md:278-278` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:280-286` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:288-295` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:297-309` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:311-316` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:318-322` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:324-333` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:335-338` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:340-345` | From a record to a card block, Merging a write. Retain arithmetic, error/type/protection conditions, directory marks, sequential key and historical SAVE count. |
| `tec-os/17-sd-card-and-volumes.md:347-347` | Combine or replace with the corresponding subject noun-phrase heading. |
| `tec-os/17-sd-card-and-volumes.md:349-353` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:355-359` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:361-378` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:380-393` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:395-397` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:399-404` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:406-406` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:407-425` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |
| `tec-os/17-sd-card-and-volumes.md:427-430` | Volume services and publication. Retain ABI/register/slot/stack contracts, flush/publish/reset/default selection, lifetime and complete historical slot capture/TPA comparison. |

## Semantic source proof

All unprefixed coordinates below are at ea3ef3d. I read the whole SD driver,
volume mount and helpers, the BIOS disk routines, volume-service and reselection
routines, format definitions, relevant host creator/parser and cache paths.
The BDOS error, selection, close, reset and dispatcher callers were read with
their containing routines. Test sources are read as assertions, never as newly
passing results.

| Claim group | Mechanism, exact proof and wording boundary |
| --- | --- |
| Port and SPI helpers | layout.asm:21-24 definesFDh. sd.asm:40-106 clocks MOSI and samplesMISO, preservesSPIEND registers/R1. SPIW is the actual label, notSPIW8. sd.asm:119-172 sends arguments/CRC and boundsR1 to16 bytes. No external CRC reconfiguration is inferred. |
| Initialisation | sd.asm:215-396 proves tenCMD0 attempts with80 clocks each, conditionalCMD8 echo, 256CMD55/ACMD41 attempts with256-turn pause, immediateCMD55 rejection, OCR/CCS and conditionalCMD16. The echo check follows onlyR1=1, not every response and not a proof that every skipped check belongs to an old card. Error paths meetSDFAIL:385-388; success clearsSDERR:393-396. |
| Address conversion | sd.asm:398-438 reads little-endianSDLBA, high-capacity SETARG and standard shift9. Both highbyte/bit23 guards precedeSDARG stores. Read:447-452 and write:735-740 enterSDRNG:511-515 before a command. LastLBA7FFFFF becomesFFFFFE00. This ceiling is addressability, not measured capacity. |
| Read/write bounds | sd.asm:447-515 distinguishesR1error5, FE data, FF wait, other-tokenerror10 and 65536-poll timeout6, reads but ignoresCRC. sd.asm:735-806 bounds response16 and busy65536, masksresponse1F=05, treats any nonzero byte as busy end. Errors7/8 remain separate. |
| Timing scopes | sd.asm:470-472 contains INC A and untakenJR NZ, 4+7=11T for extra FF classification only. 78127ec:docs/diagnostics.md:285-291 gives678T for a diagnostics fullpoll. Historical original17:111-116 supplies219144/216164 and4MHz55ms. No current fullpoll or timing run is claimed. |
| Transfer and no-stack scope | sd.asm:517-724 contains unrolledbits, I256 two-byte readpasses, DE two256-byte writepasses and latch restoration beforeRET. cache.asm:222-275 sets/clearsSDXB. boot.asm:49-58 setsIM1. bios.asm:247-252,284-291 plusCDI/CEI:441-478 and vol.asm:668-678 supply callers' interrupt guards. Maskable interrupts only, no arbitrary NMI guarantee. |
| Header format and generator | format/format.json:2-43 defines sizes/counts/fields, tools/build.mjs:78-135 emitsformat/geom. vol.asm:56-186 implements ordered header checks and minor0 versus nonzero. container.mjs:79-87 chooses minor1 for>8 ordrives. Header checksum uses volutil.asm:92-136 and vol.asm:592-622 modulo16bit. |
| Zero-extra-table exception | vol.asm:197-206 branches straight toMNV2 forcount/16=0, bypassing comparison234-239 even whenstoredMNTSUMnonzero. container.mjs:130-148 still compares tableSum; its helper:41-49 computes empty0. Read the corrected AppendixE draft and e-pass-record, including independent closure751e8b2. E's exception is preserved without implying universal hostsuperset. |
| Table/cache ownership | vol.asm:477-545 invalidates/refills based onMNTCB, resetsLBA afterCTAKE; cache.asm:247-290 remapsBIOSrecord aftervictimwrite. vol.asm:548-622 copies32 throughMNBUF/MVCOPY, sums512 without stack underEXP1. MNBUF ram.asm:114-116. Actual eviction failure returns beforeCFILL. |
| Descriptor fields and publication | vol.asm:262-315 checksnonzeroid, flags, geometry,exactlength andalignednonzerostart.316-385 checksorderedstart,32bitexclusiveend/container/stdmodebound.389-445 checksdrive/defaultslots/duplicates/A.413-428 installs aswalkproceeds.453-461 rollsbackallmounts onanyfailure. The opening comment atvol.asm:4-8 is inaccurate about prevalidating everydescriptor beforeanyinstall, so the draft follows instructions, not that comment. |
| Host comparison | container.mjs:130-193 checksbydefaultphysicalimageextent,cachebits,uniqueids,nonzerominoruniquelabels andotherfields. NoSDBYTE input, so noROMstandardmodecheck. Neitherpathchecksallreservedbytes. ROMignoresuppercachebits atvol.asm:750-752 anddoesnotcheckiduniqueness. No claimhostchecksareuniversalsuperset. |
| Declared versus physical length | vol.asm:330-385 boundsdeclaredlength/addressmode,notCSD. sd.asm:447-458/500-504 turnsnonzeroR1into5. bdoslog.asm:112-136 andbdoscon.asm:26-72 supplybadsector/default/returnederrormodes. sd-range.test.mjs:36-106 asserts exactstandardboundary,highcapacitystraddle andbeyond-imageR140/error5. Devicefailureform remainsconditional. |
| DPH/DPB and geometry | vol.asm:691-802 fills8-byteDRVTAB and16-byteDPH, leavesALVpointer. ram.asm:36-65 namesindex/slots. bios.asm:56-96 selectsempty/baddriveHL0, preservesDSKCURonfailure andcomputesDPHTAB+16d. format.json:47-59 andbuild.mjs:121-135 suppliesallDPBvalues,2048/512allocationblocks,4directoryallocationblocks andtracks. bdosfile.asm:19-133 provesscratchsum/dirty/mark warmrebuild. boot.asm:679-799 suppliesvectorallocation, notMNDPH. |
| Record map and read | bios.asm:20-54 savesBC/nohead/noskew.124-221 boundstrack/sector,computesrecord/slot/block andonlywritesSDLBAaftervolumecheck. BLKOFF/BLKSLOTmaymutatebeforefailure. bios.asm:247-252/441-478 andcache.asm:425-491 maps/copies128 andrestoresinterruptstate/result. |
| Read-only and close | bios.asm:284-306 storesCWTYPE/mapsbeforeROcheck,protectsmarks/cachedata,notallworkspace. bdoslog.asm:874-891 hasRONZ/CHKRO. bdosfile.asm:250-298 hasunmodifiedandreadonlyclosesuccesspaths. bdos.asm:178-212 bindsFCBdrivebeforeFNCLSE. cpm22.test.mjs:174-185 assertsneveropenedreadonlyclose. Originalcitation274-279 alonewouldonlyproveunmodifiedFCBreturn,notreadonlyclose. |
| Directory marks | bios.asm:309-366 checksBLKOFFforfirst32/16SDblocks,setsDPH+4andmaxmarkat+6 to(block+1)*16. bdosfile.asm:72-133 marksfordeferredrebuildatnextselection,warmresetselectsAinRSTAIL. Draftsayscanrebuild,notallvolumesscannedimmediately. |
| Merge/key/write policy | bios.asm:368-426 distinguishestype2,BUFOK2,samedrive,immediatepredecessor andallocationboundarymask. cache.asm:510-554 zeroslineevenonhit,GETKEYbios:230-239 setsdrive/block/2. cache:568-605 keepskeyonlyforsameblock/drive. Type2stilldependsonthecallercontract. cache:596-651 merges128/setsdirty,throughwriteandbehindtype1data-before-directory. SAVE18writes/0readsremains78127ecfixture,countincludes2directorywrites. |
| Numbered interface | abi.asm:12-20 plusabi.inc:27-29/115-135 fixC008h andnumbers9/10/11. volsvc.asm:204-236/397-403 implementsentry,descriptorcopy/currentdrive.246-315 validatesdrive/index/notalreadyanywhere/slots;463-506 readsdescriptor/currentassignment.326-368 guardsunmountA/Dandreturnsstatus. Describehasreadfailures,notjustindexfailure. |
| Stack proof boundary | abi.inc:35-58/115-135 defines24bytesincludingdispatcherandBDOSnonreentry. storage-boundaries.test.mjs:197-241 staticallycontains6/allNLINESdirtycases,maskedcachewalkwatch,descriptoridentityand<=24assertions. No stackmeasurement newlygenerated. |
| Flush and assignment boundary | volsvc.asm:413-429 preservesBC/DE/IXaroundCDI/CFLALL/CEI. cache.asm:292-350 attemptsalllines,dropsfailedonesandaggregatesNZ. volsvc:246-284/326-368 publishesonlyafterflushsuccess. Failurepreservesassignmentbutcanpersistotherbytes/dropfailedlines. Noall-media-rollback. |
| Reset/default and lifetime | volsvc:265-284/326-358/436-455 clears/publishes/indexesandresetsvia37;377-391 reselectsdefaultvia25/14. bdosfile:135-174 publishesDEFDPB/DEFALV. LaterBDOSerrorispostpublication,notcoveredbyvalidationrollback. boot:7-14/127-137 andvolsvc:31-159 retainrecognisedvalidatedselectionelsedefaults. Noheaderassignmentrewrite. |
| Slot capture/TPA | Original17:399-430 retains78127ecformat1.0two-slotcapture andfour-slot46564TPA/704difference. test/programs/mount.asm:159-212 callstheactualinterfaces. boot:679-799 allocates4*256versusstarter64+256,1024-320=704. ActualhistoricalabsoluteTPAisnotasource-offermeasurement. |

## Draft checkpoint

A generous whole-text draft and this material/source record precede the
reduction passes. The original's three complete output fences and three
capture recipes are preserved. The reader prose contains no excluded editorial
review link or work-history correction paragraph. Source-comment corrections
and authority comparisons belong in this record.

Manual craft and literal checks continue after this checkpoint. No automated
prose gate, complexity report, build, assembler, emulator, test, product import
or capture has been run under the explicit no-execution instruction.

## Completed authorial passes

The generous draft and material/source proof were committed and pushed as
427ebcc before these final reductions. I read the complete chapter in reader
order, then the complete changed passages after the corrections below.

| Pass | Actual finding and disposition |
| --- | --- |
| Mechanical gate | Manual searches located optional commas before then/so/and, no prose semicolon or em dash and no question-shaped heading. Removed the optional conjunction commas and reader-process wording. The source instruction JR NZ,SDRERR retains its literal comma. No automated prose score or script pass is claimed. |
| Thematic/teaching order | Kept byte/command layout before SDINIT, addressing before transfer errors, container validation before DPH/DPB and the record map before merging. Preserved both failure demonstrations beside declared/physical capacity. Added a worked arithmetic mapping after MAPREC: track2,sector5 givesrecord133,offset33,slot1; start2048 givescard2081,bytes128–255. This is arithmetic from instructions, not an invented run/output. |
| Paragraph deletion | Removed the reader-facing paragraph's source-comment dispute from the mount explanation. The actual walk/install/rollback mechanism remains and the stale comment is documented only in semantic proof above. Removed the redundant record-map certification after READ. Replaced the final source-offer/navigation qualification with the concrete TPA cost. |
| Sentence deletion | Read every sentence in order with its paragraph and neighbouring paragraph. Removed the extra assurance that the worked example is arithmetic rather than data evidence, since the calculation itself supplies that distinction. Short definitions and error results remain because deleting them loses exact codes or bounds. Kept the separate extra11T/full678T distinction because combining them recreates the original scope error. Kept the uncached-directory caveat because SAVE's zero-read count is fixture-specific. |
| Agency and plain relations | SPI sampling is the actual input operation, not perception. Routines read, compare, select, transfer and return. The descriptor defines a range and the DPH points to memory. No card/ROM/file has thought, memory, intention or social agency. Replaced generic contract praise with exact protected drive-assignment state and explicit side effects. |
| Every comma | Read every comma-bearing sentence and table row. Removed optional then/so/and commas, mode-condition pauses and the DPH/DPB appositions. Retained numeric separators, genuine list boundaries, error-code/name appositions and clarifying subordinate boundaries. No Oxford comma, authorial semicolon or em dash remains. Immutable historical punctuation and trailing spaces remain. |
| Technical recheck | Qualified the512-byte receive onFEh rather than allowing then to imply continuation after an error token. Corrected SPIW to the actual label. Replaced copied stale line coordinates with the actual ea3 instruction ranges for LBAARG/SDRNG, transfer loops, latch returns and BRET/CEI. Read the split BDOS error caller: bdoslog:112-136 reaches bdoscon:26-72. RONZ/CHKRO is bdoslog:874-891, not the earlier login range. Read bdosrec's actual write-type/BIOS caller and random-write ROFCB path with bdosfile:421-445. No name-only mapping is accepted. |
| Exact condition review | CMD8 skips echo foranyR1otherthan1. Standard limit compares exclusiveend<=800000 while lastblock<=7FFFFF. Hostzeroextrasum differs from ROMskip. Directory marking tests mappedaddress; warm rebuilding is deferred to nextselection for a logged-in changed drive. RO blocks data/marks afterworkspaceupdates. Key correctness assumes propertype2. Flushfailure protectsassignment but notcache/media rollback. Defaultreselections arepostpublication. |
| Preservation | All55 assigned units have a disposition. Three complete output fences and allthree capture recipes compare byte-identically with10821b6. The short/bad image preparations, retry keys, historical timings, SAVE count and historical TPA figures remain at78127ec. No capture was replaced by a link or repinned. |
| Journey/navigation | Read the entire chapter from128-versus512 through the final704-byte slot cost. Each section uses the preceding address/state vocabulary. The closing result is a concrete capacity cost, not a recap or roadmap. Both Chapter14 anchors exist in its current draft. AppendixB/D/E links use final-root sibling filenames present in tec-os/, not ../../../ paths or excluded editorial review links. Root integration is a later task. |

### Final evidence boundaries

The geometry derivation was also read at tools/lib/format.mjs:9-40. It uses
the JSON DPB unchanged, checks64records/OFF0/CKS0 and derives allocation/vector
sizes and tracks. No generated artifact was built or imported. The shared
128-byte DIRBUF declaration is ram.asm:67. Read-only file writes call ROFCB
at bdosrec.asm:350-359 and CHKRO at bdosfile.asm:430-445 before BIOS output.
The directory mark's next-selection scope follows bdosfile.asm:72-133 rather
than an assertion that every changed drive is rebuilt immediately at warmboot.

The three historical fences, including trailing spaces, and three capture
recipes are preserved literally. Current source mechanisms and historical
measured results remain separate. No newly passing test, stack observation,
card behaviour or cycle measurement is claimed. The worked record mapping
adds arithmetic explanation only. No currentKS48font/default is asserted.

No build, execution, product import, assembly, emulator, capture or runtime
verification was performed. Full craft passes were manual under the explicit
no-execution constraint, which overrides running the skills' prose-analysis
scripts. Static text comparisons, source-object reads and range/link checks
supply literal evidence. Independent result review remains open.

## Final static comparison

All three fences and three capture recipes compare byte-identically with
frozen10821b6 after the final edits. All five final-destination links exist,
including the two Chapter14 anchors. The final chapter has132 current source
range occurrences across24 files, plus the explicitly historical diagnostics
range. Each range was checked against its pin and read in mechanism/caller
context as recorded above. FNWRITE at bdosfile.asm:645-664 callsROFCB before
WRITESEQ, completing the sequential as well as random read-only caller proof.
The written-through sentence explicitly conditions reported success on a
successful card write. The owned-path whitespace check is clean. Other
writers' staged, modified and untracked paths are excluded from both commits
with git commit --only and exact Chapter17 paths.

## Independent confirmation

Full independent review at7d9dafe found no actionable source, preservation, editorial, punctuation or journey findings. All55 assigned units accounted for.
Historical evidence remains historical. Final navigation, source/profile and
runtime qualification remain open. No execution accompanied the review.

## Source adoption reconciliation

I applied the current-source citation reconciliation selected at `9ba1f59`.
The mechanism authority is now `962853f`. The original source audit and
`source-adoption-unaffected-application.json` record the exact citation
changes, range evidence and input/output hashes. Earlier entries above retain
the source identities and review limits in force when I wrote them.

I read the changed paragraphs and citation contexts in full. Historical
results, source fixtures and dependency pins retain their original scope.
The reader’s fences and capture comments are unchanged. Editorial gate
results and context dispositions are recorded in the application JSON.
Independent application review remains open. No product code ran.
