---
layout: default
title: "Appendix 2 — Expression Operators"
parent: "Appendices"
grand_parent: "AZM Books"
nav_order: 2
---

# Appendix 2 — Expression Operators

## Operator table

Operators in precedence order, lowest to highest. Operators at the same precedence level are left-associative.

| Operator | Operation | Precedence |
|----------|-----------|------------|
| <code>&#124;</code> | bitwise OR | 1 (lowest) |
| `^` | bitwise XOR | 2 |
| `&` | bitwise AND | 3 |
| `<<` | left shift | 4 |
| `>>` | right shift | 4 |
| `+` | add | 5 |
| `-` | subtract | 5 |
| `*` | multiply | 6 |
| `/` | integer divide | 6 |
| `%` | modulo | 6 (highest binary) |

Unary operators (highest precedence): `+` (identity), `-` (negate), `~` (bitwise NOT). Parentheses group sub-expressions and override precedence.

All expressions are evaluated by the assembler before the binary is written.

## Numeric literal formats

AZM accepts eight numeric literal forms. They can be mixed within one expression.

| Form | Example | Base | Notes |
|------|---------|------|-------|
| `$` prefix | `$FF`, `$0100` | hex | Bare `$`, or `$` before a non-hex character, is the current assembly address |
| `0x` prefix | `0xFF`, `0x2A` | hex | prefix is case-insensitive |
| Trailing `H`/`h` | `0FFH`, `02Ah` | hex | must start with a decimal digit; `FFH` parses as a symbol name |
| `%` prefix | `%10101010`, `%1111` | binary | |
| `0b` prefix | `0b10101010`, `0b1111` | binary | prefix is case-insensitive |
| Trailing `B`/`b` | `10101010B`, `10b` | binary | |
| Plain decimal | `42`, `255`, `0` | decimal | |
| Quoted character | `'A'`, `"Z"` | ASCII value | single character; valid in any expression context |

**Trailing-`H` rule:** the token must begin with a decimal digit (`0`–`9`). `0FFH` is hex 255. `FFH` starts with a letter, so the parser reads it as a symbol name. The forms `$FF` and `0FFH` force hexadecimal interpretation.

`%` has two roles: a `%` at the start of a value is a binary literal prefix; a `%` between two expressions is the modulo operator.
