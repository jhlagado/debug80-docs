# Chapter 28 pass record

Current mechanism authority is TEC-OS `962853f499f05faf281f6cdff1deca8959f58c2b`.
The selected-source adoption section at the end records the current correction
and supersedes earlier source/profile holds. Earlier sections preserve the
initial ea3 audit and its historical evidence accounting. Their old coordinates
remain scoped to that initial audit rather than silently repinned.

## Contract and authority

The chapter explains how to interpret and reproduce host-model evidence.
Its reader has the runtime mechanisms and the PC setup from5/26. The route
is shared machine, card/time inputs, write watches, observation channels,
stopping/input/snapshot limits, the complete LINES fixture, tests/inputs,
browser implementation and the boundary of physical evidence.

Only draft/28-the-host-model-as-evidence.md and this record are owned.
That draft filename follows the explicit bounded authoring request. The shared
revision ledger still proposes28-reproduce-the-evidence.md. Navigation
integration must reconcile that difference later. No shared ledger was edited.

The closed replacement outline at0e4feea, closure3060e71 and controlling
movement map at10821b68f80c10d2037bbd1c5ab207877c897c68 govern preservation.
Read all62 destination28 whole units and the explicit index:49–50 fragment.
Read the entire old27-host-model.md, all old02:334–396 fixture material and
its pagination context, the containing index conventions and the complete
current outline and source-question dispositions before drafting.

Current mechanisms use Git source text at TEC-OS
ea3ef3de9133931e925a0220d51c0e971c1fd8dd. All six retained captures and their
recipes remain TEC-OS78127ec evidence. The original host chapter names
@jhlagado/debug80-runtime0.3.3. The offered package names the same version,
but equality of a version or source range does not qualify a later artifact.
The original LINES chapter names78127ec without a separate application pin.
The examples are not physical-board evidence and were not rerun here.

The source-only pass changes no font/default or startup policy. Qualification
of the planned40-column opening remains held. Historical GLCD/other screen
examples are not substituted for that workflow.

## Complete source reading

Read the complete host/machine.mjs at the offered pin.
Read complete test/lib/fixtures.mjs, test/lib/machine.mjs, test/lib/inputs.mjs,
tools/capture.mjs, tools/lib/pins.mjs, tools/lib/cpmfs.mjs, web/build.mjs,
web/src/store.mjs and tools/diag-check.mjs. Read the containing browser
machine, timing/render/input, save, whole-image and file-import paths.
Read host/card.mjs's full staged rewrite and failure handling, test inputs,
package definitions, the media recipe owner and README setup/evidence scope.
The ROM pager and the deliberate-watch tests were read in context.

| Claim | Semantic proof at ea3ef3d unless explicitly historical |
| --- | --- |
| Shared machine and symbols | host/machine.mjs:10–27 imports runtime/bytes and maps D8 names. test/lib/machine.mjs:3–12 owns Node file/font setup. host/machine.mjs:186–212,240–243 uses symbols and rejects missing named symbols. No claim that an arbitrary map works with any ROM |
| Options, memory and runtime | host/machine.mjs:33–85,122–176 defines all constructor options, I/O wiring, ROM placement, absent window and optional MAIN/EXPAND mapping. Display timer suppression is updateMs=Infinity, not a claim that host scheduling has no effects |
| Card and range | host/machine.mjs:59–74,122–140,522–526 attaches/swaps the runtime card model. test/sd-range.test.mjs:36–106 asserts standard7FFFFF/exclusive800000 limits and beyond-image command failure. These assertions are not a fresh passing run |
| Clock | host/machine.mjs:86–119 advances a supplied clock and subsequent written time from emulated cycles. test/lib/fixtures.mjs:72–73 and tools/capture.mjs:72 set different fixed starting dates. The browser supplies no fixed date. No wall-clock-to-physical-clock equivalence |
| ROM/overlay CPU watch | host/machine.mjs:215–237 records attempts before the underlying hook and exposes fixture write bypass. test/system.test.mjs:14 checks empty violations. test/diag.test.mjs:78–90 expects deliberate diagnostic violations, not an empty list |
| EXPAND watch | host/machine.mjs:177–225 finds the clear and allowed ranges from symbols, leaves BD00h outside the watch and limits the shared list to16. test/lib/machine.mjs:14–34 asserts/checks/traces that list. test/expand.test.mjs:67–77 deliberately writes BF80h and removes the intentional shared entry |
| Observation and settling | host/machine.mjs:259–321 samples C at ROM BCONOUT, records cycles, waits on predicates/output and settles. host/machine.mjs:323–342 finds input loops and ready state. tools/capture.mjs:74–96 combines prompt, pending input, pager and diagnostic conditions |
| Input pacing | host/machine.mjs:354–371,453–520 implements serial reception waits, held matrix keys/modifiers and queued fallback. A physical terminal's freely arriving input is not established by that paced path |
| Text versus pixels | host/machine.mjs:380–450 masks PICO reverse bits and decodes GLCD cells using Machine.font. tools/capture.mjs:43–50 and test/lib/machine.mjs:8–10 supply the parser output. tools/capture.mjs:147–153 supplies PIWID width. Font decoding is not independent font/default/pixel qualification |
| Capture tool | tools/capture.mjs:5–39,53–132 defines configuration, command notation, starting-card hash and waits. Its final output normalises carriage returns and can append LCD/screen rows. The starting hash is not an output-card hash |
| Reset and RAM image | host/machine.mjs:528–546 copies mapped RAM plus selected EXPAND window, not every optional bank. Its578–587 resets CPU/latches while retaining memory/card. Device state, CPU registers and input queues are not all serialised into ramImage |
| Fixture recipes and caching | test/lib/fixtures.mjs:21–79 reads ROM/map, digests source/includes, uses origin in cache names and builds empty standardCard/service fixtures. Its93–121 owns withDisplay/boot. The key omits tool/runtime identities and volume explicitly passes readOnly:false |
| CP/M host file access | tools/lib/cpmfs.mjs:128–173 rejects out-of-range blocks and protects ordinary erase/write;175–233 plans and writes files. The shared library does not make privileged fixture setup a ROM protection test |
| External inputs | test/inputs.json gives two pinned files. tools/lib/pins.mjs:10–49 selects override/local/legacy without fallback from a selected stale entry. test/lib/inputs.mjs:24–41 distinguishes skip, strict failure and mismatch. No download or import was performed |
| Browser test dependency | package.json:17–18,28 fixes serial test command/strict flag and Playwright version. test/deps.test.mjs:14–27 asserts declared/lock/install documentation. It is source evidence of the checks, not proof of installation or execution |
| Browser distribution | web/build.mjs:1–45 bundles and clears/copies output, aliases fs and selects one ROM. tools/media.mjs:204–236 supplies SAMPLE/ABI/DEMO and page recipe components. An alias is not described as proof that a particular fs import is live |
| Frame/input/render | web/src/main.mjs:174–233 targets4MHz, caps elapsed100ms and checks a30ms budget every1024 instructions. Its358–427 decodes serial display text and routes keys. Displayed MHz is achieved host execution speed |
| Save/preparation/import | web/src/main.mjs:92–166,617–649 plus web/src/store.mjs:42–59 supplies timer, save guards, failure and staged import publication. host/card.mjs:58–72,104–116 stages display-line rewriting. The noSave exception permits memory-only import. Neither download nor import flushes ROM cache |
| Pager/LINES meaning | src/cpm/ccpfile.asm:335–366,451–520 gives dimensions, pause erasure, case-insensitive Q and CHPOS clearing for Ctrl-C. Original old02:334–396 supplies the complete historical recipe/screens. No new screen claim |
| Physical comparison | README.md:27–28 records model-only scope. host/machine.mjs:40–46,155–172 distinguishes legacy/documented mapping. docs/diagnostics.md:146–163,185–195 explains overlay/latch/bank probes. tools/diag-check.mjs:24–44,70–106,136–160 matches image identity, compares measured forms and reports unpaired tests. Zero differences is not universal physical qualification |

## Source inventories and original discrepancies

The original prose says56 test files at78127ec. A top-level Git-tree scan
of test/*.test.mjs counts55 at that historical pin and57 at ea3ef3d.
The draft uses the offered count57 with explicit source-only wording.
The stale56 is corrected here, not recast as a historical successful run.
No executed-test, passing-test or test-case total was generated.

At both inspected pins,27 top-level test files mention violations. One is
diag.test.mjs, which intentionally checks ROM/overlay writes. The other26
contain ordinary violation checks. The draft's26 is explicitly a source
inventory outside diagnostics, not proof that every test or machine enforces
that assertion. The Node wrapper's after-file assertion is specifically for
the shared EXPAND watch and must not be confused with a universal empty-ROM-
violation hook. Intentional watch tests remove their expected shared entries.

The old “all RAM” snapshot wording is bounded to what the helper actually
serialises. The old assertion that output contains every console byte is
bounded to the ROM BCONOUT sampling point. The old absolute conclusion that
a passing program makes neither forbidden write is replaced by checked paths,
watch coverage and explicit setup/bypass limits.

## Movement accounting

All62 whole units have the following homes. Comma-separated ranges are the
individual movement records from10821b6, not new source selections.

| Frozen units | Destination and disposition |
| --- | --- |
| old02:334–338,340–344 | A complete pagination fixture. Separate historical card, exact ten-line text preparation, copy and put recipe |
| old02:346–347,349–349,350–359 | First GLCD pause, exact capture recipe and complete unchanged screen |
| old02:361–364,366–366,367–376 | Wrapping/scroll/count interpretation, exact x-continuation recipe and screen |
| old02:378–384,386–386,387–396 | Ctrl-C versus Esc/Q chain scope and exact first-pause q recipe/screen |
| old27:1–6,8–8,10–11,13–15 | New navigation and separate mechanism/evidence metadata. Historical runtime/capture pin retained, no citation-only repin of results |
| old27:17–22,24–24,26–33 | Opening and A shared machine. Shared Node/browser module, D8 symbols and matched-input requirement |
| old27:35–35,37–48 | Complete constructor options table with meanings and RAM mapping scope |
| old27:50–55,57–61 | Runtime responsibilities, memory/ROM placement and display timer suppression |
| old27:63–63,65–72 | Card bytes and time. Separate SdSpi attachment, mutable image, swap and ROM reset distinction |
| old27:74–81,83–90,92–95 | Standard/high-capacity and image bounds, DS1302 attachment, host versus cycle clock and both fixed dates |
| old27:97–97,99–104,106–109 | Write watches. ROM/overlay attempted-write records, diagnostics distinction and bounded26-file source inventory |
| old27:111–117,119–125 | Full EXPAND watch bounds, clear/writer recognition, history exclusion, shared16 cap, test wrapper and deliberate BF80h example |
| old27:127–127,129–134,136–138 | Console bytes, serial bytes and screens. Sampling point and routes, qualified for bypasses |
| old27:140–140,141–151,153–153,155–155,156–163,165–165,167–167,168–173 | All three original GLCD observations in order, all capture/continuation comments and fences unchanged |
| old27:175–184 | Commands and stopping conditions. Predicate/output/settling/input/ready/capture waits |
| old27:186–194 | Serial/matrix and queued pacing, modifiers and physical-arrival distinction |
| old27:196–206 | PICO layouts/width/cells, font-dependent GLCD decoding, RAM image/load and reset. All-RAM claim narrowed to actual serialised layout |
| old27:208–208,210–220 | Fixtures, assertions and pinned inputs. Test command, corrected source inventory, ROM/boot/display fixture and existing startup preservation |
| old27:222–235 | ATOM programs/cache/digest, makeSvc, standardCard and shared CpmVolume/error/attribute contracts |
| old27:237–252 | External application pins, input preparation/selection, strict versus skip, browser dependency/setup and dependency checks |
| old27:254–254,256–270 | The browser as another caller. Build order/bundle/stub/clean copy, one ROM and width/startup/media/DEMO relationship |
| old27:272–281,283–287 | Frame rate/budgets, display state, MHz/host clock, focus input and serial presentation |
| old27:289–298,300–306 | Dirty card/IndexedDB identity, save timer/failure, staged display rewrite, import/save/publication/reset and explicit cache-flush prerequisite |
| old27:308–308,310–313 | From a model result to a board observation. Historical model scope and offered README boundary |
| old27:315–318,320–326 | Observability stricter than a board, legacy/runtime differences and bounded meaning of a passed path |
| old27:328–333 | Diagnostic T08/T10/T12 route and image-specific board/model comparison, measured/noncompared limits |
| index:47–50 | T-state/cycle/4MHz/microsecond convention in Card bytes and time under the explicit fragment override. Hex/size conventions retain the front-matter home |

The index:49–50 fragment is fully retained. All assigned LINES preparation,
three capture recipes, screens and interpretations remain together here.
It is not a prerequisite for the new Chapter3 SAMPLE route. No capture has
been reduced to a link. Seven fences compare exactly with the frozen source:
six text captures and one shell preparation. The five complete capture
command comments plus the original screen-continuation comment are unchanged.
The owned-path whitespace check flags only four padded A:/B: lines in the
two retained boot captures. Those historical spaces are preserved literally.

## Completed craft and verification passes

1. The complete assigned reading and source check preceded a generous draft.
   The opening establishes the evidence question and observation channels.
   The text keeps mechanism, assertion, recorded run and board observation
   separate throughout rather than relying on a final disclaimer.
2. Mechanical vocabulary/agency/heading searches were performed. Artifact
   operations use read, sample, execute, compare, record, write and return.
   A match does not prove unexercised paths. No praise, staged question or
   imagined intent was retained. Immutable captures keep their literal spacing.
3. The thematic pass read each paragraph for its job and prerequisites.
   Inputs precede watches, channels precede screen examples and stopping
   conditions precede the pagination fixture. Host setup is crosslinked before
   shell preparation. The browser implementation follows the shared machine.
4. The sentence-deletion pass read every sentence in order. Removed the old
   syllabus opening and unqualified “everything/all RAM/every passing program”
   conclusions. Removed reader-facing preservation-process wording and the
   reference to the machine on which source was read. Kept exact watch,
   queue, storage and snapshot limits because
   each changes the interpretation of an apparent success.
5. The agency pass and separate every-comma/punctuation reading covered all
   retained and new prose. No authorial semicolon, em dash or Oxford comma
   remains. The final reader-order pass ends on the precise scope of a matching
   board line rather than a recap or a promise of hardware equivalence.
6. The technical/literal pass compared all seven fences with their frozen
   sources, checked all reproduction comments and read the changed claims
   against their owners/callers. All81 chapter source-range occurrences were
   checked for bounds through Git
   text. The original diagnostic comparator citation was corrected to its
   actual160-line source. No product was imported or executed.
7. Navigation uses the requested Chapter28 draft filename and current sibling
   destinations for5/13/17/26/27 and I. Shared references still naming the
   ledger's28-reproduce-the-evidence path require later integration. The
   independent chapter review and whole-book reader-order review remain open.

## Delivery boundary

Own source, preservation and craft passes are complete. Independent
editorial/factual review remains required. Final source/media navigation and
new opening-profile qualification remain pending. No tests, assemblies, model
runs, browser actions, captures, builds, imports, physical measurements or
publication were performed. A source-only inventory or equality comparison
has not been reported as a new passing result.

## Independent and lead read closure

The complete independent factual/editorial review atbbd6b10 found no blocker.
The lead subsequently read the complete450-line chapter including all retained
fences, the full pagination fixture, source assertion versus passing-run
boundaries, browser persistence and physical-board limits. No further local
finding was found. This closes the bounded draft review, not final adopted
source, font/default proof, navigation or whole-book acceptance. Nothing ran.

## Bounded draft-navigation correction

The independent navigation audit read all297 reference-containing passages
and found two actionable mismatches. Chapter28 now consistently uses the
authored title The host model as evidence and filename
28-the-host-model-as-evidence.md across the draft index, Chapter27 link,
outline and ledger. Its job and position remain unchanged. The earlier
pass-record naming hold is superseded by this reconciliation.
Chapter19's specific BIOS-hook replacement explanation now points to
Chapter16's The BIOS boundary rather than10's raw-call interface.
The separate10 reference for the writable table remains correct and unchanged.
The lead read all changed containing passages and the destination section.
No root navigation, renderer or product ran. Independent bounded confirmation
and final integrated navigation remain separate. Opening1–3 links remain held.

## Current 40-column pagination evidence home

The complete current pagination fixture is retained at Origo e77c7ef0,
`studies/p3-tec-os/evidence/book-reader-rewrite/next-batch-attempt02/complete-attempt.tar.gz`.
Its independent result receipt is review4b5b5a50,
`studies/p3-tec-os/reviews/book-opening-workflows.md`. I read that complete
receipt and all three result objects below as inert archive data. This entry
is the reproduction-accounting home for Chapter3's paused-screen excerpt.
It adds no reader-facing runtime recipe or new execution claim.

Each case starts on its own fresh card and machine. The actual input is
`TYPE A:SAMPLE.ASM!USER 1` with a Return, not plain TYPE. The continuation
case supplies Space at each pause. The other two supply Escape or Ctrl-C
at the first pause. The continuation prints the complete 5,105-byte source
with ten pauses before USER 1. Escape stops at the same 539-byte source prefix
and permits USER 1. Ctrl-C stops there and drops it. The terminal prompts are
therefore 1A>, 1A> and A> respectively.

| Complete archive member | Bytes | SHA-256 |
| --- | ---: | --- |
| stage/results/type-continue.json | 5950 | 840f72e6f7d5742f65272309d13402e094da31bcd432d5db80eee1972b022cba |
| stage/results/type-escape.json | 795 | 8a1481c21ed324119111e16fdf4f8217ca1a9853699291670b1d8fc1963f7552 |
| stage/results/type-ctrl-c.json | 782 | 5474bc27f3bed492e59b100b7f850b35cb67d41461c66b3fa6ed9bff4c07b6d5 |

The first paused VRAM identity is the same in all three cases, SHA-256
`745350432bceb0bc25d92799807fc6e769c9ef704a8b3718568b3c54de702bb8`.
The archive retains the complete inputs, screens, registers, masks and card
evidence rather than only the Chapter3 excerpt. No echoed command or later
prompt may be rewritten to imply an independently captured plain TYPE run.
The ordinary command explanation in3 does not require a premature chain or
user-area lesson. Exact excerpt boundaries remain with that chapter's record.

The original78127ec GLCD LINES recipe, all three screens and their comments
remain together in reader Chapter28 unchanged. This new current fixture does
not replace or repin them. Source authority for the new evidence is tested
8b8664a, landed962853f with ROM fa63989b and PICO record3. Acceptance is scoped
to the covered public cases. The batch remains FAILED at a later observer.
No advanced-service, physical, browser, audible or whole-book acceptance follows.

I read the complete existing pass record before this addition, then checked
the new paragraphs in order for preservation, agency and every comma. The
mandatory prose gate and complexity report are editorial checks only. No
reader Chapter28 text, output fence, capture comment or old evidence changed.

The gate reports zero findings. The sole new complexity prompt is the short
Ctrl-C consequence, retained because it distinguishes cancellation from Escape.
Older prompts are unchanged historical pass accounting.

## Selected-source adoption at 962853f

Book selection 9ba1f59 authorises current mechanisms at TEC-OS
`962853f499f05faf281f6cdff1deca8959f58c2b`. The tested source is
`8b8664a7d93c6dc2e8bce509b9770585e106eedc`. The latter differs from the
adopted descendant only in the two KS48 qualification records. Proposal 18's
qualified offer and independent result receipt remain Origo 43d5f328.
Opening workflow receipt 4b5b5a50 and complete opening reviews d9d57d2/b911e84
close their bounded scopes. They do not certify a browser or physical board.
The opening batch remains FAILED globally at its later observer.

I read both source-adoption impact records, all 35 contexts, 29 proof spans
and nine historical exceptions. I read this entire reader file and its full
existing pass record before editing. The actual ea3-to-962 executable diff
was read with the complete owning build, media, font, startup and fixture
functions. Unchanged cited spans were compared byte for byte with the prior
semantic audit and read against their containing claims. Diagnostic, ROM,
host and browser source contexts were inspected as Git text. No source
identity comparison is a runtime result.

The browser preparation account now states an explicit CON PICO line for
every selected width. Its default preference is still 80, distinct from raw
cold 40. The test helper has a different condition: with PICO and matrix input
it adds a width line for a width other than 40 when startup is absent. Its
argument default remains 80 and an existing startup file remains intact.
The adopted Git tree has 61 top-level test files and 28 ordinary violation
check files outside diagnostics. These are inert source inventories, not test
outcomes. The two new ordinary-check files are compact-display.test.mjs and
compact-transitions.test.mjs. Their complete bodies were read as assertions.
The PIWID decoder fallback remains 80. GLCD's six-pixel cell matching remains
distinct from five-pixel font data. All old LINES and GLCD observations retain
their actual configuration and provenance.

The owned impact dispositions are IM010 and IM029.

### Citation coverage

All 83 current reader range occurrences across 23 source files
were reconciled before changing the mechanism header. The table includes
shorthand ranges in their owning file. The earlier sections of this record
keep the original ea3 audit coordinates under that explicit scope. This new
table uses only 962853f. Bounds and byte correspondence supplement the
mechanism readback, not an execution claim.

| Source | Adopted ranges | Exact Git blob | Comparison with ea3 |
| --- | --- | --- | --- |
| `host/machine.mjs` | 10–16, 23–27, 33–78, 40–46, 51–55, 59–74, 63–78, 72–119, 77, 80–85, 122–140, 126–137, 143–176, 155–172, 175, 177–225, 186–212, 215–233, 223–233, 237, 240–243, 259–267, 269–321, 323–342, 354–371, 380–410, 412–450, 453–520, 522–526, 528–550, 579–587 | `eb1a1e5f30e1cb10750ec4a7a31486279631ac02` | same blob |
| `test/lib/machine.mjs` | 3–12, 8–10, 14–34 | `9e618bac2d8c98dfd6dfe9cb846dc04cf098b037` | same blob |
| `web/src/main.mjs` | 5–12, 17–43, 82–95, 92–152, 144–166, 174–233, 358–427, 617–649 | `80f5af6c81ddeb6195ad89ad15cb9415f3ffea9e` | same blob |
| `test/sd-range.test.mjs` | 36–106 | `bbec6fc45c7f42768f5af65384091a459cbb07f3` | same blob |
| `test/lib/fixtures.mjs` | 21–27, 29–55, 57–70, 72–73, 75–79, 93–121 | `8aca336619b9c28f79b9b264caea4933905c6ad4` | changed source read |
| `tools/capture.mjs` | 5–39, 43–50, 67–73, 72, 76–96, 98–132, 147–153 | `aa1bf00ecbe6ac2b324bfb5a624ecd21af2a3a35` | same blob |
| `test/system.test.mjs` | 14 | `f0af975dc16cbc76ae4b8898a9534a2ef39005fb` | same blob |
| `test/diag.test.mjs` | 78–90, 121–123 | `cc631c853c8416ac2b59d2475295dd2279659db2` | same blob |
| `test/expand.test.mjs` | 67–77 | `b566d5c2d641605665cdcb7d9ba60e8358ac0acd` | same blob |
| `src/cpm/ccpfile.asm` | 335–366, 451–520 | `072affdf19ea070549d6029cdf204ed8f2b29cfd` | same blob |
| `package.json` | 17, 18, 28 | `9c4c13a74c6137d6b108b66e7491b62ddc8398ac` | same blob |
| `tools/lib/cpmfs.mjs` | 128–173, 175–233 | `869bcd39ce8f3735df5b0c9c7f4d6e31413f21ff` | same blob |
| `tools/lib/pins.mjs` | 10–49 | `5288ad2d02508d29145860c01bc27107e64f89c7` | same blob |
| `test/lib/inputs.mjs` | 24–41 | `9cb7f0a7c286f4bf5b12bd180c1f39aab61f3e69` | same blob |
| `test/deps.test.mjs` | 14–27 | `69416fbe4daf59b4217aeb2e280dbfc9443c2fe5` | same blob |
| `web/build.mjs` | 1–45 | `b33b5a836a20743daac110f89fa0a6a236929247` | same blob |
| `tools/media.mjs` | 206–238 | `ff0436be705f846bbb712a5837f8757bb7d6bd30` | changed source read |
| `web/src/store.mjs` | 6–8, 42–59 | `c1698a67efd60d5394b5d45e33b70f1041f28317` | same blob |
| `host/card.mjs` | 58–72, 104–117 | `9cfb87a88462a12082058e611187f83d603ccaa8` | changed source read |
| `src/pico.asm` | 36–92 | `0c49c294fc3199b619a994394d1b2b4192d17d0b` | changed source read |
| `README.md` | 27–28 | `16388dcfa7561c14b03ab585ea33a3c2c4eb0e59` | changed source read |
| `docs/diagnostics.md` | 146–163, 185–195 | `02f04d493514a82d74451b15f3cc4692b2e0ef41` | same blob |
| `tools/diag-check.mjs` | 24–44, 70–106, 136–160 | `80199ab2d7dd81b12a62d34a8ba002108d96c514` | same blob |

The current native offer remains ROM
`fa63989b65d1e7e7a07f45e2a2b33e52f785d74216a3fde38af86b2d913f302d`
and D8
`9a87dec39a63efc8fdf38ae13d6ec6299763c833fc891de121e2b30f4a1a36ac`.
These existing qualified identities remain the offer authority. Native 16020
used and 364 free already occur in the ea3 memory-map account. No change
from historical 16018/366 is attributed to font growth.
Equal map addresses do not transfer historical provenance.

### Preservation and craft

All 7 reader fences and 6 capture/continuation comments match the
input byte for byte. This includes their whitespace. Source listings,
recipes, measurements, maps, hashes and build or screen output were not
rewritten. Existing historical pins remain explicit. The protected digest
below joins complete blocks with a single LF separator.

| Identity | SHA-256 |
| --- | --- |
| Reader input | `bdcdd4237f288331dd233333bcdb0810971f5969c9cdfbeb5c147a9cb3100a97` |
| Reader output | `c2f9bd746a4a13f6f58253af9adae81c11da769e8f4a593b8bdadd3349b84b63` |
| Protected fence aggregate | `6999655e9d01add324b14a112a75e66386db75b623882afbae5e0be8d608697e` |

The intervention is a mechanism/citation correction within the existing
route. Separate thematic and deletion passes kept preflight before generation,
normal operation before failure and each historical example under its own
provenance. Each changed sentence was read within its full paragraph or table
row and across the next boundary. Agency and every-comma passes retained
necessary lists and exact interface punctuation. The reader-order pass kept
the practical prerequisites and the existing ending. No example was replaced
with a source assertion or an invented result.

This adoption closes the owned current-source hold only. Independent adoption
review, whole-book reconciliation and publication remain separate. No product
import, syntax check, assembly, build, test, model, capture, browser action,
physical operation or new runtime allocation occurred.

### Editorial gate dispositions

The actual mandatory prose gate and sentence-complexity report ran on all eight
owned files. These are inert editorial checks. No hard gate finding remains.
The five review flags were read in their complete contexts and retained:

| Gate location | Disposition |
| --- | --- |
| 26 record line 183, columns 134 and 352 | Two matches in the initial agency-pass explanation. It denies interior agency and records a removed attribution. It does not assign that agency to a program. |
| I reader line 123, column 23 | The word refers to interface messages as a plural noun, not an act of perception. |
| I record line 29, column 24 | The same plural noun identifies source-defined interface messages in the initial audit. |
| I record line 66, column 217 | The main script appends bracketed interface messages. This is an output operation. |

The reader's count prompts distinguish source files from a passing workload.
Both exclusions remain necessary: a file count proves neither execution nor
unexercised paths. Time-unit repetition supplies an actual conversion. Watch,
decoder, pacing and snapshot prompts retain their separate state/coverage limits.
The cache-key prompts distinguish a recursive source digest from complete tool
identity. Short pager statements separate Q, erasure and historical provenance.
Browser-copy, serial-display and measured-line prompts name distinct operations
and the limits of their observation. Initial-record prompts retain the original
audit history and current pager handoff. New helper-condition wording retains
all three prerequisites. The decoder and receipt prompts preserve their exact
parameter and review identities.

Every complexity prompt was used for a sequential reading decision. The report
also splits code spans, metadata and list continuations into apparent short
sentences. Those fragments were judged in their complete paragraphs or rows.
The initial audit was preserved rather than rewritten for a score. The final
changed-passage readback confirmed prerequisites, exceptions and provenance.
