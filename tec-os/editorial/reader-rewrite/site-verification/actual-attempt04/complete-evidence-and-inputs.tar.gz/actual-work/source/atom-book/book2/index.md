---
title: "Atom Book 2 — Z80 Programming"
nav_order: 4
sidebar_link: "Book overview"
---

<Mark class="book-plate" book="atom" size="52" />

# Atom Book 2 — Z80 Programming

## Chapters

- [Introduction](00-introduction.md)

### Foundations

1. [The Computer](01-the-computer.md)
2. [Machine Code](02-machine-code.md)
3. [Assembly Language](03-assembly-language.md)
4. [Memory Access and Data](04-memory-access-and-data.md)
5. [Flags, Comparisons and Jumps](05-flags-comparisons-jumps.md)

### Loops, data and routines

6. [Counting Loops and DJNZ](06-counting-loops-and-djnz.md)
7. [Data Tables and Indexed Access](07-data-tables-and-indexed-access.md)
8. [Stack and Subroutines](08-stack-and-subroutines.md)
9. [I/O and Ports](09-io-and-ports.md)
10. [A Complete Program](10-a-complete-program.md)
11. [Subroutine Conventions](11-subroutine-conventions.md)

### Applied algorithms

12. [Arithmetic Routines](12-arithmetic-routines.md)
13. [Sorting and Searching](13-sorting-and-searching.md)
14. [Strings](14-strings.md)
15. [Bit Patterns and Packed Flags](15-bit-patterns.md)
16. [Recursion](16-recursion.md)

[Exercise Notes](exercise-notes.md)

## Reference tables

- [Numbers, bits and ASCII](../appendices/07-numbers-bits-and-ascii.md)
- [Registers, flags and conditions](../appendices/08-registers-flags-and-conditions.md)
- [Addressing, prefixes and instruction forms](../appendices/09-addressing-prefixes-and-instruction-forms.md)
- [Z80 instruction reference](../appendices/10-z80-instruction-reference.md)
