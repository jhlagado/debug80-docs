UNQUALIFIED_PUBLIC_RUNNER_FIXTURE_NOT_BOOK_ACCEPTANCE
Public runner integration only. Actual Node and guard; synthetic installed dependencies and checker.
The carried 39 expectations and 48 checker controls are unchanged reference inputs, not results of this fixture.
