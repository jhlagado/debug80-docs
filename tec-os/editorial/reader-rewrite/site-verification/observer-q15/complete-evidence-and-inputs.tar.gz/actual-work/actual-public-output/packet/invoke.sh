#!/bin/sh
echo "Use the allocated public_observer_fixture.py CLI" >&2
exit 2
