"""UNQUALIFIED fixture receipt writer; no HTML validation."""
import argparse
import json
import os
from pathlib import Path
p = argparse.ArgumentParser()
for name in ('expect', 'dist', 'receipt'):
    p.add_argument('--' + name, required=True)
a = p.parse_args()
value = {'status': 'passed', 'fixture_only': True,
         'scope': 'UNQUALIFIED_PUBLIC_RUNNER_FIXTURE_NOT_BOOK_ACCEPTANCE',
         'checked': {}, 'real_html_validation': False}
with Path(a.receipt).open('x') as f:
    f.write(json.dumps(value) + '\n')
    f.flush()
    os.fsync(f.fileno())
print('UNQUALIFIED fixture receipt only; no book validation')
